# YPRの計算に便利なように季節を展開し、年齢を(nage+1)の3倍までのばした
# F,partialF,Z,M,成熟率x産卵量,漁法別四半期年齢あたり平均漁獲体重の行列を求める。
#
# argument
# faa          : object calculated by calFAA.ss3.x
# year         : vector of integer to calculate average F at age
# fmult        : multiplier of F
# fmodifier    : modifier of F intensity by fleet
# R0           : number of fish at age 0, usually defined as 1
# spawnseason  : Spawning season
# debug        : Logical value if debug is on (default : FALSE)
# SSver        :
# geomean      : Logical value if geometric mean to be applied or not (default=TRUE)
#
# return value
# 以下を要素に持つlist
#　fmort.matrix : 2 dimensional array (nageseason x nfleet+3+1+nfleet+1), storing F@A and partial F@A,
#                 Z, M, Spawning output at age, W@A by fleet and number of survivor at age conditioned as R0=1 for YPR
# nage         : nage as defined in SS
# nseason      : number of season
# nfleet       : number of fleet
# nageseason   : (nage+1)*nseason
# nageseason3  : 3*(nage+1)*nseason
# spawnseason  : Spawning season
# fmult        : multiplier of F
# fmodifier    : modifier of F intensity by fleet
# R0           : number of fish at age 0, usually defined as 1
# faa          : object returned by cal
# year         : vector of integer to calculate average F at age
#
#
calcFAA.ypr<-function(faa,year,fmult=1,fmodifier=1,R0=1,spawnseason,debug=FALSE,SSver=3,geomean=TRUE){
  nage<-dim(faa$faa.array)[2]-1
  nfleet<-dim(faa$faa.array)[3]
  nseason<-nlevels(factor(faa$naa$Seas))
  if(SSver==3){
    sortlist<-order(faa$nma$Age_Beg)
  }else{
    sortlist<-order(faa$nma$age_Beg)
  }
  nma.sorted<-faa$nma[sortlist,]
  nageseason<-(nage+1)*nseason
  nageseason3<-3*nageseason

  ## 幾何平均を計算するために0の代わりに1を代入した
  fmort<-array(0,dim=c(nageseason3,nfleet+3+1+nfleet+1),dimnames=list(seq(from=0,by=1.0/nseason,length.out=nageseason3),
    c("Total",paste("F_FL",1:nfleet,sep=""),"Z","M","Mat.Fec",paste("SelW",1:nfleet,sep=""),"N")))
#  browser()
  if(length(dim(faa$faa.array))==4 & dim(faa$faa.array)[4]==1){
    nametemp<-dimnames(faa$faa.array)
    dim(faa$faa.array)<-dim(faa$faa.array)[1:3]
    dimnames(faa$faa.array)<-nametemp[1:3]
  }
#  cat(paste(ifelse(geomean,"geomean\n","arithmatic mean\n")))
  # まず年四半期x年齢のF@Aの幾何平均を計算する
  # 幾何平均の場合は、要素がすべて1,算術平均では、要素がすべて0
  fmort1<-array(ifelse(geomean,1,0),dim=c(nseason,nage+1))

  if(length(year)>1){
    for(y in year){
##################
      temp1<-faa$faa[as.numeric(rownames(faa$faa))==y+(1 :nseason-1)*1.0/nseason,]
      if(length(temp1)==0){cat("length(temp1)=",length(temp1));browser()}
      if(geomean){
      ###  幾何平均
        fmort1<-fmort1*temp1
      }else{
##################
#    算術平均
        fmort1<-fmort1+temp1
      }
#      temp<-faa$faa.array[as.numeric(dimnames(faa$faa.array)[[1]])==y+(1 :nseason-1)*1.0/nseason,,]
#        if(length(temp)==0){cat("length(temp)=",length(temp));browser()}
#        dim(temp)<-c(nageseason,nfleet)
#      fmort[seq(1,nageseason),2:(nfleet+1)]<-fmort[seq(1,nageseason),2:(nfleet+1)]+temp

    }
    if(geomean){
      fmort1<-fmort1^(1/length(year))
    }else{
      fmort1<-fmort1/length(year)
    }
#### partial F@Aに分けるために、対象とする期間の平均のpartial C@Aを計算する
#### この部分は算術平均
    caa1<-array(0,dim=c(nseason,nage+1,nfleet))
    for(y in year){
      temp1<-faa$caa.array[as.numeric(dimnames(faa$caa.array)[[1]])==y+(1 :nseason-1)*1.0/nseason,,]
 #     browser()
      caa1<-caa1+temp1
    }
    caa1<-caa1/length(year)
#fmo    browser()
#       dim3<-dim(faa.array)[3]
#    #    faa.array<-(faa/(totcatch+1.e-16))%o%rep(1,dim3)*caa$caa.array
#        faa.array<-(faa/(totcatch*(totcatch>0)))%o%rep(1,dim3)*caa$caa.array
#        faa.array[which(caa$caa.array==0,arr.ind=TRUE)]=0     #### 2011/02/24 ある年四半期年齢で漁獲が全くないときに、F@A にNAが出てしまうので、そこを0に修正、
    totcatch<-apply(caa1,c(1,2),sum)
     dim3<-dim(faa$faa.array)[3]
    fmort2<-(fmort1/(totcatch*(totcatch>0)))%o%rep(1,dim3)*caa1
    fmort2[which(caa1==0,arr.ind=TRUE)]=0
    fmort2.org<-fmort2
    dim(fmort2)<-c(nageseason,nfleet)
#    fmort2<-cbind(apply(fmort2,1,sum),fmort2)
      fmort[1:nageseason,2:(nfleet+1)]<-fmort2
#    fmort<-fmort/length(year)
#    fmort<-fmort^(1/length(year))
#    cat("fmort=",fmort[seq(1,nageseason),2:(nfleet+1)],"\n")
# fmort[seq(nageseason+1,nageseason3),2:(nfleet+1)]<-fmort[nageseason-nseason+1:nseason,2:(nfleet+1)]

  }else{
    temp<-faa$faa.array[as.numeric(dimnames(faa$faa.array)[[1]])==year+(1:nseason-1)*1.0/nseason,,]
    if(length(temp)==0){cat("length(temp)=",length(temp));browser()}
    dim(temp)<-c(nageseason,nfleet)
    fmort[seq(1,nageseason),2:(nfleet+1)]<-temp
#   fmort[seq(nageseason+1,nageseason3),2:(nfleet+1)]<-fmort[nageseason-nseason+1:nseason,2:(nfleet+1)]%o%rep(1,(nage*2))
  }
#  browser()
  if(length(fmult)!=1){
    stop("fmult must be scalar")
  }else{
#   browser()
    if(length(fmodifier)!=1 && length(fmodifier)!=nfleet)stop("length(fmodifier) must be equal to number of fleet(nfleet) or scalar")
#   for(i in 1:nfleet)
#   {
#     fmort[,i+1]<-fmort[,i+1]*fmodifier[i]*fmult
#   }
#   browser()
#   fmort[,1:nfleet+1]<-fmort[,1:nfleet+1]*fmodifier*fmult
    fmort[1:nageseason,1:nfleet+1]<-t(apply(fmort[1:nageseason,1:nfleet+1],1,function(x){tmp<-x*fmodifier*fmult;return(tmp)}))
  }
# Calculate total F
  fmort[,1]<-apply(fmort,1,sum)
# Set M
  fmort[1:nageseason,"M"]<-nma.sorted$M[1:nageseason]/nseason
# fmort.df<-as.data.frame(fmort)
# Calculate Z
  fmort[1:nageseason,"Z"]<-fmort[1:nageseason,"Total"]+fmort[1:nageseason,"M"]
# cat("length(Z)=",length(fmort.df$Z),"\n")
# cat("Z=",fmort.df$Z,"\n")
# MaturityxFecundity
  fmort[seq(spawnseason,nageseason,by=nseason),"Mat.Fec"]<-nma.sorted$"Mat*Fecund"[seq(spawnseason,nageseason,by=nseason)]
# mean weight by fishery
#  fmort[1:nageseason,nfleet+4+1:nfleet]<-data.matrix(nma.sorted[1:nageseason,20+(1:nfleet-1)*3])
# Biology matrix に列が追加になっても列名が変わらなければ対応出来るように　2010/02/15
  fmort[1:nageseason,nfleet+4+1:nfleet]<-data.matrix(nma.sorted[1:nageseason,paste("SelWt:_",1:nfleet,sep="")])
# Calculate numbers at age in equiribrium with R0 upto nageseason

  fmort[1,"N"]<-R0
# fmort.df$N[1]<-R0
  for(age in 1:(nageseason-1)){
#   fmort.df$N[age+1]<-fmort.df$N[age]*exp(-fmort.df$Z[age])
    fmort[age+1,"N"]<-fmort[age,"N"]*exp(-fmort[age,"Z"])
  }

# Extend matrix to nage*3
  temp<-aperm(fmort[nageseason-nseason+1:nseason,]%o%rep(1,((nage+1)*2)),c(1,3,2))
  dim(temp)<-c(nageseason*2,nfleet+3+1+nfleet+1) # totalF, partialF(10), Z,M,matxFec,mean weight by fleet(10),N : 1+10+1+1+1+10+1
  fmort[seq(from=nageseason+1,to=nageseason3),]<-temp

# Calculate numbers at age in equilibrium from nageseason to nageseason3

  for(age in nageseason:nageseason3-1){
#   fmort.df$N[age+1]<-fmort.df$N[age]*exp(-fmort.df$Z[age])
    fmort[age+1,"N"]<-fmort[age,"N"]*exp(-fmort[age,"Z"])
  }

#  if(debug){edit(fmort);browser()}
#  browser()
  return(list(fmort.matrix=fmort,nage=nage,nseason=nseason,nfleet=nfleet,
    nageseason=nageseason,nageseason3=nageseason3,spawnseason=spawnseason,
    fmult=fmult,fmodifier=fmodifier,R0=R0,faa=faa,year=year))
}


##### calcFAA.yprの返り値を、fmultとR0で修正する
#
# argument
#
# fmult        : multiplier of F
# fmort.list   :
# R0           : number of fish at age 0, usually defined as 1
# debug        : Logical value if debug is on (default : FALSE)
#
# returns
# 以下を要素に持つlist
#　fmort.matrix : 2 dimensional array (nageseason x nfleet+3+1+nfleet+1), storing F@A and partial F@A,
#                 Z, M, Spawning output at age, W@A by fleet and number of survivor at age conditioned as R0=1 for YPR
# nage         : nage as defined in SS
# nseason      : number of season
# nfleet       : number of fleet
# nageseason   : (nage+1)*nseason
# nageseason3  : 3*(nage+1)*nseason
# spawnseason  : Spawning season
# fmult        : multiplier of F
# fmodifier    : modifier of F intensity by fleet
# R0           : number of fish at age 0, usually defined as 1
# faa          : object returned by cal
# year         : vector of integer to calculate average F at age
# geomean      : average F to be calculated by geometricmean (TRUE) or arithmetic mean (FALSE),default :TRUE
#
#
modifyFAA.ypr<-function(fmult=1,fmort.list,R0=1,debug=FALSE,geomean=TRUE){
  if(missing(fmort.list)){cat("fmort.list is missing");browser()}
  fmort.matrix<-fmort.list[["fmort.matrix"]]
  nage<-fmort.list[["nage"]]
  nseason<-fmort.list[["nseason"]]
  nfleet<-fmort.list[["nfleet"]]
  nageseason<-fmort.list[["nageseason"]]
  nageseason3<-fmort.list[["nageseason3"]]
  fmodifier<-fmort.list[["fmodifier"]]
  faa<-fmort.list[["faa"]]
  spawnseason<-fmort.list[["spawnseason"]]
  year<-fmort.list[["year"]]
  if(fmult!=fmort.list[["fmult"]] && fmort.list[["fmult"]]!=0){
#   browser()
    fmort.matrix[,1:(nfleet+1)]<-fmort.matrix[,1:(nfleet+1)]*fmult/fmort.list[["fmult"]]
    fmort.matrix[,"Z"]<-fmort.matrix[,"M"]+fmort.matrix[,1]
    fmort.matrix[1,"N"]<-R0
#   browser()
    for(age in 1:(nageseason3-1)){
      fmort.matrix[age+1,"N"]<-fmort.matrix[age,"N"]*exp(-fmort.matrix[age,"Z"])
    }
  }else if(fmort.list[["fmult"]]==0){
    if(length(faa)==0){cat("length(faa)=",length(faa));browser()}
    if(is.null(year)){cat("year=",year);browser()}
    fmort.tmp<-calcFAA.ypr(faa=faa,year=year,fmult=fmult,fmodifier=fmodifier,R0=R0,spawnseason=spawnseason,debug=debug,geomean=geomean)
    fmort.matrix<-fmort.tmp[["fmort.matrix"]]
  }

  return(list(fmort.matrix=fmort.matrix,nage=nage,nseason=nseason,nfleet=nfleet,
    nageseason=nageseason,nageseason3=nageseason3,spawnseason=spawnseason,
    fmult=fmult,fmodifier=fmodifier,R0=R0,faa=faa,year=year))
}

##########################################
## fmortを修正する
# To-do 要チェック : modifyFAA.yprと同じ？
# Argument
#
# fmort :
# fmult        : multiplier of F
# R0           : number of fish at age 0, usually defined as 1
# spawnseason  : Spawning season
# debug        : Logical value if debug is on (default : FALSE)
#
# Return
#
# fmort        : list returned calFAA.ypr
#
modifyFmort.ypr<-function(fmort,fmult=1,R0=1,spawnseason,debug=FALSE){
  if(debug)browser()
  if(fmult!=fmort$fmult){
    fmult.old<-fmort$fmult
    fmort$fmult<-fmult
    fmort$fmort.matrix[,1:(fmort$nfleet+1)]<-fmort$fmort.matrix[,1:(fmort$nfleet+1)]*fmult/fmult.old
    fmort$fmort.matrix[,"Z"]<-fmort$fmort.matrix[,"M"]+fmort$fmort.matrix[,1]
  }
  if(R0!=fmort$fmort.matrix[1,"N"]){
    fmort$R0<-R0
    fmort$fmort.matrix[1,"N"]<-R0
#   browser()
  }
  for(age in 1:(fmort$nageseason3-1)){
    fmort$fmort.matrix[age+1,"N"]<-fmort$fmort.matrix[age,"N"]*exp(-fmort$fmort.matrix[age,"Z"])
  }
  if(spawnseason!=fmort$spawnseason)  fmort$spawnseason<-spawnseason
  return(fmort)
}


# 四半期年齢別、漁法別漁獲重量を計算する
calcCW.ypr<-function(fmort.list){
  fmort<-fmort.list[["fmort.matrix"]]
  nage<-fmort.list[["nage"]]
  nseason<-fmort.list[["nseason"]]
  nfleet<-fmort.list[["nfleet"]]
  nageseason<-fmort.list[["nageseason"]]
  nageseason3<-fmort.list[["nageseason3"]]
  cw_fl<-array(0,dim=c(nageseason3,nfleet))
  colnames(cw_fl)<-paste("FL",1:nfleet,sep="")

  OneMinusExpZ<-1-exp(-fmort[,"Z"])

  OneMinusExpZperZ<-OneMinusExpZ/fmort[,"Z"]

## partial F と catch weight by fleetの積
## 結果は四半期齢で収納
#  cw_fl[,1:nfleet]<-fmort[,2:(nfleet+1)]*fmort[,nfleet+4+1:nfleet]
  cw_fl[,1:nfleet]<-fmort[,paste("F_FL",1:nfleet,sep="")]*fmort[,paste("SelW",1:nfleet,sep="")]

  cw_fl<-cw_fl *  fmort[,"N"]*OneMinusExpZperZ

  return(invisible(cw_fl))
}

# 四半期年齢別、漁法別漁獲重量を計算する
# calcCAA.yprを利用することにした
calcCW.ypr.new<-function(fmort.list){

# 四半期年齢別、漁法別漁獲尾数
 caa_fl<-calcCAA.ypr(fmort.list)
## catch weight by age and by fleetをかけて漁獲重量に変換
## 結果は四半期齢で収納
  cw_fl[,1:nfleet]<-cw_fl[,1:nfleet]*fmort[,nfleet+4+1:nfleet]

  return(invisible(cw_fl))
}

# 四半期別年齢別、漁法別漁獲尾数を計算する
calcCAA.ypr<-function(fmort.list){
  fmort<-fmort.list[["fmort.matrix"]]
  nage<-fmort.list[["nage"]]
  nseason<-fmort.list[["nseason"]]
  nfleet<-fmort.list[["nfleet"]]
  nageseason<-fmort.list[["nageseason"]]
  nageseason3<-fmort.list[["nageseason3"]]
  caa_fl<-array(0,dim=c(nageseason3,nfleet))
  colnames(caa_fl)<-paste("FL",1:nfleet,sep="")

  #browser()

  OneMinusExpZ<-1-exp(-fmort[,"Z"])

  OneMinusExpZperZ<-OneMinusExpZ/fmort[,"Z"]

## partial F と catch weight by fleetの積
## 結果は四半期齢で収納
  caa_fl[,1:nfleet]<-fmort[,2:(nfleet+1)]

  caa_fl<-caa_fl *  fmort[,"N"]*OneMinusExpZperZ

  return(invisible(caa_fl))
}

#
# SPR(絶対値）が与えられたときに対応するfmultiplierを計算する
#
## 2010/02/10 高速化するために他の求解法に切り替える
## 2011/03/15 percentがtrueであれば、%SPRに対応するfmultiplierを返すようにした。
##
SPR2fmult<-SPR2fmult.20100210<-function(spr=NA,perc_spr=NA,faa=NULL,year,R0=1,spawnseason=4,fmort.list=NULL,
  fmodifier=ifelse(is.list(faa),rep(1,dim(faa$faa.array)[3]),
  fmort.list[["fmodifier"]]),range=c(0,5),tol=0.01,debug=FALSE,percent=FALSE,geomean=FALSE){
# 下限と上限は初期設定では0と5
  fmultLow=range[1]
  fmultHigh=range[2]

  sprLow<-calcSPR.ypr(faa=faa,year=year,fmult=fmultLow,R0=R0,spawnseason=spawnseason,
            fmort.list=fmort.list,fmodifier=fmodifier,geomean=geomean)
  sprHigh<-calcSPR.ypr(faa=faa,year=year,fmult=fmultHigh,R0=R0,spawnseason=spawnseason,
            fmort.list=fmort.list,fmodifier=fmodifier,geomean=geomean)
##########################################################################
  fnc<-function(x){
    if(!percent){
      val<-spr-calcSPR.ypr(faa=faa,year=year,fmult=x,R0=R0,spawnseason=spawnseason,
                    fmort.list=fmort.list,fmodifier=fmodifier,geomean=geomean)$spr
    }else{
      val<-perc_spr-calcSPR.ypr(faa=faa,year=year,fmult=x,R0=R0,spawnseason=spawnseason,
                    fmort.list=fmort.list,fmodifier=fmodifier,geomean=geomean)$perc_spr
    }
    return(val)
  }
#  browser()
##########################################################################
  temp<-uniroot(f=fnc,interval=c(fmultLow,fmultHigh),tol=min(tol,1.0e-6))
#  browser()
  return(temp$root)
}

## 2010/02/10 高速化するために他の求解法に切り替える
PERC_SPR2fmult<-PERC_SPR2fmult.20100210<-function(perc_spr,faa=NULL,year,R0=1,spawnseason=4,fmort.list=NULL,
  fmodifier=ifelse(is.list(faa),rep(1,dim(faa$faa.array)[3]),fmort.list[["fmodifier"]]),range=c(0,5),
    tol=0.01,debug=FALSE,geomean=TRUE){
# 二分法で計算する初期値は初期設定では0と5
  fmultLow=range[1]
  fmultHigh=range[2]

  sprLow<-calcSPR.ypr(faa=faa,year=year,fmult=fmultLow,R0=R0,
              spawnseason=spawnseason,fmort.list=fmort.list,fmodifier=fmodifier,geomean=geomean)
  sprHigh<-calcSPR.ypr(faa=faa,year=year,fmult=fmultHigh,R0=R0,
              spawnseason=spawnseason,fmort.list=fmort.list,fmodifier=fmodifier,geomean=geomean)
##########################################################################
  fnc<-function(x){
    return(perc_spr-calcSPR.ypr(faa=faa,year=year,fmult=x,R0=R0,
              spawnseason=spawnseason,fmort.list=fmort.list,fmodifier=fmodifier,geomean=geomean)$perc_spr)
  }
##########################################################################
  temp<-uniroot(f=fnc,interval=c(fmultLow,fmultHigh),tol=min(tol,1.0e-5))
#  browser()
  return(temp$root)
}


#
# SPRをss2の計算方法に基づいて計算する
# 年単位、または年の範囲で指定する
#
# 実態は次のgetFmort.ypr.0のwrapper
#
calcSPR.ypr<-function(faa=NULL,year,fmult=1,R0=1,spawnseason=4,fmort.list=NULL,
  fmodifier=ifelse(is.list(faa),rep(1,dim(faa$faa.array)[3]),fmort.list[["fmodifier"]]),debug=FALSE,geomean=TRUE){

  tmp<-getFmort.ypr.0(faa=faa,year=year,fmult=fmult,R0=R0,spawnseason=spawnseason,fmort.list=fmort.list,
    fmodifier=fmodifier,debug=debug,geomean=geomean)

  spr<-tmp$spr
  spr0<-tmp$spr0
  perc_spr<-tmp$perc_spr
  R0<-tmp$R0
  fmult_return<-tmp$fmult

  return(list(spr=spr,spr0=spr0,perc_spr=perc_spr,R0=R0,fmult=fmult_return))
}

#
#  YPRをss2での漁獲量の計算方法に基づいて計算する
#  年単位、あるいは年の範囲で指定する
#
#  fmult : Fへのmultiplier すべての漁業に一律にかける
#  fmodifier : 漁法ごとに、Fを何倍するかを指定する
#  例 : getFmort.ypr(year=2004,faa=faa)
#  2008/5/4 コードの整理とfmultをfmultとfmodifierに分けた
#  faa : calcFAA.ss2の返りオブジェクト、
#
#  2009/09/12 defaultの引数を変更した
#  faa とfmot.listの両方が与えられた際には、fmort.listを優先する

#getFmort.ypr<-function(faa=-1,year,fmult=1,R0=1,spawnseason=4,maximize=FALSE,fmult.opt=NA,fmort.list=NA,
# fmodifier=ifelse(is.list(faa),rep(1,dim(faa$faa.array)[3]),fmort.list[["fmodifier"]]),
# stepsize=0.001,interval=c(0,5),F0.1=TRUE,debug=FALSE){

getFmort.ypr.old<-function(faa=NULL,year,fmult=1,R0=1,spawnseason=4,maximize=FALSE,fmult.opt=NA,fmort.list=NULL,
  fmodifier=ifelse(!is.null(faa),rep(1,dim(faa$faa.array)[3]),fmort.list[["fmodifier"]]),
  stepsize=0.001,interval=c(0,5),F0.1=TRUE,debug=FALSE){

  if(is.null(faa)&&is.null(fmort.list)){cat("ERROR");browser();stop("Either faa or fmort.list must be given in arguments list")}
  if(is.null(fmort.list)&&!is.null(faa)&&is.list(faa)){
    nage<-dim(faa$faa.array)[2]-1
    nfleet<-dim(faa$faa.array)[3]
    nseason<-nlevels(factor(faa$naa$Seas))
  # sortlist<-order(faa$nma$age_Beg)
  # nma.sorted<-faa$nma[sortlist,]
    nageseason<-(nage+1)*nseason
    nageseason3<-3*nageseason
    if(length(faa)==0){cat("in getFmort.ypr, length(faa)=",length(faa));browser()}
    fmort<-calcFAA.ypr(faa=faa,fmult=fmult,fmodifier=fmodifier,year=year,spawnseason=spawnseason,R0=R0,debug=debug)
  }else if(!is.null(fmort.list)  && is.list(fmort.list)){
   # browser()
    if(is.null(fmort.list))browser()
  #  cat("here\n")
    fmort<-modifyFAA.ypr(fmort.list=fmort.list,fmult=fmult,R0=R0,debug=debug)
    nage<-fmort.list[["nage"]]
    nfleet<-fmort.list[["nfleet"]]
    nseason<-fmort.list[["nseason"]]
  # sortlist<-order(faa$nma$age_Beg)
  # nma.sorted<-faa$nma[sortlist,] x
    nageseason<-fmort.list[["nageseason"]]
    nageseason3<-fmort.list[["nageseason3"]]
  }
  if(missing(fmort.list))fmort.list<-NULL
  if(missing(faa))faa<-NULL
##########################################################################################
## current or modifyed Fでのsprを計算
  calc.spr<-function(fmort,debug=FALSE){
    spr<-sum(fmort[["fmort.matrix"]][,"N"]*fmort[["fmort.matrix"]][,"Mat.Fec"])
    if(debug)browser()
    return(spr)
  }


##########################################################################################
## current or modifyed Fでのsprを計算
# spr<-sum(fmort[["fmort.matrix"]][,"N"]*fmort[["fmort.matrix"]][,"Mat.Fec"])
#  if(debug)browser()
  spr<-calc.spr(fmort=fmort,debug=debug)
##########################################################################################
## spr_F=0を計算
  if(fmult!=0 && sum(fmodifier)!=0){
    temp0<-getFmort.ypr(year=year,fmult=0,fmodifier=fmodifier,fmort.list=fmort,R0=R0,spawnseason=spawnseason)
##    fmort<-modifyFAA.ypr(fmort.list=fmort.list,fmult=0,R0=R0,debug=debug)
    #browser()
    spr0<-temp0$spr
  }else{
    spr0<-spr
  }
#########################################################################################
## %spr_current_or_modifiedFを計算
  perc_spr<-spr/spr0
# cat("length(N)=",length(fmort.df$N),"\n")
# cat("N=",fmort.df$N,"\n")

####################################################
## catch weight by fleet and by ageを計算
 cw_fl<-calcCW.ypr(fmort)

 if(debug)write.csv(cw_fl,"cw_fl.csv")
# write.csv(fmort.df,"fmort.csv")
## ypr を計算
  ypr<-sum(cw_fl)

####################################################
## ypr by fleet を計算
  ypr.fl<-apply(cw_fl,2,sum)
  if(debug)cat(paste(ypr,"\n",sep=""),file="ypr.txt",append=TRUE)
  ypr.0.1.tmp<-NULL

#######################################################
## ypr,ypr by fleet, catch weight by fleet and by age
  calc.ypr<-function(fmort){
    cw_fl<-calcCW.ypr(fmort=fmort)
    ypr.fl<-apply(cw_fl,2,sum)
    ypr<-sum(ypr.fl)
    return(list(ypr=ypr,ypr.fl=ypr.fl,cw_fl=cw_fl))
  }

####################################################
## maximize==T ならばFmaxを計算

  if(!maximize){
  ## maximize が偽なのでdummyの値を入れる
    ypr.opt<-NA
    ypr.fl.opt<-NA
    fmult.opt<- NA
    spr.opt<-NA
    fmult.0.1<-NA
    ypr.detail<-NA
    ypr.detail.opt<-NA
  ####################################################################################
  ## 以下はFmaxを計算する場合、
  }else if( fmult==0){
  ## fmult==0の場合
  ## f-multiplierは、current-F*fmultに対するf-multiplierではなく、currentFに対するf-multiplier
      if(debug)browser()
      ypr.maximizer<-optimize(f=function(x){fmultx<-x;temp<-getFmort.ypr(fmort.list=fmort,fmult=fmultx,fmodifier=fmodifier,
      year=year,R0=R0,spawnseason=spawnseason,maximize=FALSE);return(temp$ypr)},interval=interval,maximum=TRUE)

    fmult.opt<-ypr.maximizer$maximum
    spr.opt.tmp<-getFmort.ypr(year=year,fmult=fmult.opt,fmodifier=fmodifier,fmort.list=fmort,R0=R0,spawnseason=spawnseason,maximize=FALSE)
    spr.opt<-spr.opt.tmp$spr
    ypr.opt<-ypr.maximizer$objective
#   browser()
    if(F0.1)ypr.0.1.tmp<-calcF0.1(fmodifier=fmodifier,year=year,R0=R0,spawnseason=spawnseason,fmort.list=fmort,stepsize=stepsize)
#   ypr.opt<-spr.opt.tmp$ypr
    ypr.fl.opt<-spr.opt.tmp$ypr.fl
    ypr.detail.opt<-spr.opt.tmp$ypr.detail

  }else if(is.na(fmult.opt)){
    if(debug)browser()
    ypr.maximizer<-optimize(f=function(x){fmultx<-x;temp<-getFmort.ypr(fmort.list=fmort,fmult=fmultx,fmodifier=fmodifier,
      year=year,R0=R0,spawnseason=spawnseason,maximize=FALSE);return(temp$ypr)},interval=interval,maximum=TRUE)

    fmult.opt<-ypr.maximizer$maximum
#    fmort.opt<-modifyFmort.ypr(fmort,fmult=fmult.opt,R0=R0,sapwnseason=spawnseason,debug=debug)
#    modifyFmort.ypr<-function(fmort,fmult=1,R0=1,spawnseason,debug=FALSE)
#    spr.opt<-calc.spr(fmort)
#    ypr.opt<-calc.ypr(fmort)

    spr.opt.tmp<-getFmort.ypr(year=year,fmult=fmult.opt,fmort.list=fmort,R0=R0,spawnseason=spawnseason,maximize=FALSE,F0.1=FALSE)
    spr.opt<-spr.opt.tmp$spr
#   ypr.opt<-ypr.maximizer$objective
    ypr.opt<-spr.opt.tmp$ypr
    ypr.fl.opt<-spr.opt.tmp$ypr.fl
    ypr.detail.opt<-spr.opt.tmp$ypr.detail
 #   browser()
    if(F0.1)ypr.0.1.tmp<-calcF0.1(fmodifier=fmodifier,year=year,R0=R0,spawnseason=spawnseason,fmort.list=fmort,stepsize=stepsize)
  }else{
    spr.opt.tmp<-getFmort.ypr(year=year,fmult=fmult.opt,fmort.list=fmort,R0=R0,spawnseason=spawnseason,maximize=FALSE,fmodifier=fmodifier,F0.1=FALSE)
    spr.opt<-spr.opt.tmp$spr
#   ypr.opt<-ypr.maximizer$objective
    ypr.opt<-spr.opt.tmp$ypr
    ypr.fl.opt<-spr.opt.tmp$ypr.fl
    ypr.detail.opt<-spr.opt.tmp$ypr.detail
  }
  rel_ypr<-ypr/ypr.opt
  rel_ypr.fl.opt<-ypr.fl/ypr.fl.opt
  perc_spr.opt<-spr.opt/spr0

  ypr.tmp<-list(ypr=ypr,ypr.fl=ypr.fl,rel.ypr=rel.ypr,spr=spr,perc_spr=perc_spr,ypr.detail.ypr.detail,fmult=fmult)
#  ypr.F0.1.tmp
#  ypr.opt.tmp<-
  tmplist2<-list(ypr=ypr.tmp,ypr.F0.1=ypr.F0.1.tmp,ypr.opt=ypr.opt.tmp,
    nage=nage,nseason=nseason,nfleet=nfleet,
    nageseason=nageseason,nageseason3=nageseason3,spawnseason=spawnseason,
    fmult=fmult,fmodifier=fmodifier,R0=R0,year=year)

  tmplist<-list(fmult=fmult,ypr=ypr,ypr.fl=ypr.fl,spr=spr,perc_spr=perc_spr,spr0=spr0,
    fmult.opt=fmult.opt,ypr.opt=ypr.opt,spr.opt=spr.opt,perc_spr.opt=perc_spr.opt,rel_ypr=rel_ypr,
      rel_ypr.fl.opt=rel_ypr.fl.opt,fmort=fmort[["fmort.matrix"]],
      nage=nage,nseason=nseason,nfleet=nfleet,
    nageseason=nageseason,nageseason3=nageseason3,spawnseason=spawnseason,fmult=fmult,fmodifier=fmodifier,R0=R0,year=year,
    ypr.F0.1=ypr.0.1.tmp$ypr, fmult.0.1=ypr.0.1.tmp$fmult,ypr.detail=cw_fl,ypr.detail.opt=ypr.detail.opt)
  class(tmplist)<-"ypr"
  return(tmplist)

    cateq<-function(f,m,n,w=1){
    cat<-f/(f+m)*(1-exp(-f-m))*n*w
    return(cat)
  }

##########################################################################################
## current or modified Fでのsprを計算
  calc.spr<-function(fmort,debug=FALSE){
    spr<-sum(fmort[["fmort.matrix"]][,"N"]*fmort[["fmort.matrix"]][,"Mat.Fec"])
    if(debug)browser()
    return(spr)
  }


# 漁獲方程式各種

  cateq_part<-function(f,fpart,m,n,w=1){
    Z<-f+m
    cvect<-fpart/Z
    cvect<-cvect*(1-exp(-Z))
    cvect<-cvect*n
    cvect<-w*cvect
    return(cvect)
  }

  cateq_partZ<-function(Z,fpart,n,w=1){
    cvect<-fpart/Z
    cvect<-cvect*(1-exp(-Z))
    cvect<-cvect*n
    cvect<-w*cvect
    return(cvect)
  }
  cateq_partZnoN<-function(Z,fpart,w=1){
    cvect<-fpart/Z
    cvect<-cvect*(1-exp(-Z))
    cvect<-w*cvect
    return(cvect)
  }

    cateq_partZnoNW<-function(Z,fpart){
    cvect<-fpart/Z
    cvect<-cvect*(1-exp(-Z))
    return(cvect)
  }
  cateq_partZexpZnoNW<-function(Z,expZ,fpart){
    cvect<-fpart/Z
    cvect<-cvect*expZ
    return(cvect)
  }


}

#
#  YPRをss2での漁獲量の計算方法に基づいて計算する
#  年単位、あるいは年の範囲で指定する
#
#  fmult : Fへのmultiplier すべての漁業に一律にかける
#  fmodifier : 漁法ごとに、Fを何倍するかを指定する
#  例 : getFmort.ypr(year=2004,faa=faa)
#  2008/5/4 コードの整理とfmultをfmultとfmodifierに分けた
#  faa : calcFAA.ss2の返りオブジェクト、
#
#  2009/09/12 defaultの引数を変更した
#  faa とfmot.listの両方が与えられた際には、fmort.listを優先する
##
## 2009/10/10  report を与えられた場合にはそれを最優先する
##
## 2011/03/16  calcFAA.yprでfmort.listを計算するようにした
##
getFmort.ypr<-function(report=NULL,faa=NULL,year,fmult=1,R0=1,spawnseason=4,maximize=FALSE,fmult.opt=NA,fmort.list=NULL,
  fmodifier=ifelse(!is.null(faa),rep(1,dim(faa$faa.array)[3]),fmort.list[["fmodifier"]]),
  stepsize=0.001,interval=c(0,5),F0.1=FALSE,debug=FALSE,FMSY=FALSE,SR=NULL,tol=0.001,geomean=TRUE,calcB=FALSE){

  if(is.null(year))stop("year is required for getFmort.ypr\n")
  if(!is.null(report)){
#   report<-getReport.sso(repfile=repfile)
    faa<-calFAA.ss3.x(report=report,is.plot=FALSE)
    if(missing(fmodifier))fmodifier<-rep(1,dim(faa$faa.array)[3])
  }
  if(is.null(fmort.list)){
    fmort.list<-calcFAA.ypr(faa=faa,fmult=fmult,fmodifier=fmodifier,
      year=year,spawnseason=spawnseason,R0=R0,debug=debug,geomena=geomean)
  }
  if((FMSY || calcB) && is.null(SR)){
    if(is.null(report))stop("either object SR or report is required to calculate MSY" )
    SR<-read.spawner_recruit(report=report,plot=FALSE)
  }
  ypr<-getFmort.ypr.0(faa=faa,year=year,fmult=fmult,R0=R0,spawnseason=spawnseason,fmort.list=fmort.list,
    fmodifier=fmodifier,debug=debug,geomean=geomean)

  if(maximize){
  ## fmult==0の場合
  ## f-multiplierは、current-F*fmultに対するf-multiplierではなく、currentFに対するf-multiplier
    if(debug)browser()
    ypr.maximizer<-optimize(f=function(x){fmultx<-x;temp<-getFmort.ypr.0(fmort.list=ypr$fmort,fmult=fmultx,fmodifier=fmodifier,
      year=year,R0=R0,spawnseason=spawnseason,geomean=geomean);return(temp$ypr)},interval=interval,maximum=TRUE)
    ypr.opt<-getFmort.ypr.0(faa=faa,year=year,fmult=ypr.maximizer$maximum,R0=R0,spawnseason=spawnseason,fmort.list=fmort.list,
      fmodifier=fmodifier,debug=debug,geomean=geomean)
    if(calcB){
      ypr.opt$SSB<-ypr.opt$spr*R0
      ypr.opt$Yield<-ypr.opt$ypr*R0
      ypr.opt$R<-ypr.opt$R0
    }
    ypr$rel_ypr<-ypr$ypr/ypr.opt$ypr
  }else{
    ypr.opt<-NULL
  }
  if(F0.1){
    ypr.0.1<-calcF0.1(fmodifier=fmodifier,year=year,R0=R0,spawnseason=spawnseason,
      fmort.list=ypr$fmort,stepsize=stepsize,SR=SR,calcB=calcB)
  }else{
    ypr.0.1<-NULL
  }
# New 2010/10/09 Calculation of MSY
# Maximize equiribrium Yield
# In each step given Stock-Recruitment function and F, claculate equiribrium SSB, Recruitment and Yield

  if(FMSY){
    ypr.MSY<-calcFMSY(year=year,R0=R0,spawnseason=spawnseason,faa=faa,fmodifier=fmodifier,
      fmort.list=fmort.list,debug=debug,SR=SR,calcB=calcB,geomean=geomean,intervals=intervals,tol=tol,SRfn=SRfn)
  }else{
    ypr.MSY<-NULL
  }

  ypr.obj<-c(ypr,list(ypr.opt=ypr.opt,ypr.0.1=ypr.0.1,ypr.MSY=ypr.MSY))
  class(ypr.obj)<-"ypr"
  return(ypr.obj)
}


print.ypr<-function(ypr.obj){
 print(c(ypr.obj$fmult,ypr.obj$ypr,ypr.obj$perc_spr))
}

#  getFmort.ypr.0
#
#  YPRをss2での漁獲量の計算方法に基づいて計算する
#  年単位、あるいは年の範囲で指定する
#  FmaxおよびF0.1の計算を省いた簡略版
#  fmult : Fへのmultiplier すべての漁業に一律にかける
#  fmodifier : 漁法ごとに、Fを何倍するかを指定する
#  例 : getFmort.ypr(year=2004,faa=faa)
#  2008/5/4 コードの整理とfmultをfmultとfmodifierに分けた
#  faa : calcFAA.ss2の返りオブジェクト、
#
#  2009/09/12 defaultの引数を変更した
#  faa とfmot.listの両方が与えられた際には、fmort.listを優先する

#getFmort.ypr<-function(faa=-1,year,fmult=1,R0=1,spawnseason=4,maximize=FALSE,fmult.opt=NA,fmort.list=NA,
# fmodifier=ifelse(is.list(faa),rep(1,dim(faa$faa.array)[3]),fmort.list[["fmodifier"]]),
# stepsize=0.001,interval=c(0,5),F0.1=TRUE,debug=FALSE){

getFmort.ypr.0<-function(faa=NULL,year,fmult=1,R0=1,spawnseason=4,fmort.list=NULL,
  fmodifier=ifelse(!is.null(faa),rep(1,dim(faa$faa.array)[3]),fmort.list[["fmodifier"]]),debug=FALSE,geomean=TRUE){

  if(is.null(faa)&&is.null(fmort.list)){
    cat("ERROR at the begining of getFmort.ypr.0")
    browser()
    stop("Either faa or fmort.list must be given in arguments list")
  }
  if(is.null(fmort.list)&&!is.null(faa)&&is.list(faa)){
#    nage<-dim(faa$faa.array)[2]-1
#    nfleet<-dim(faa$faa.array)[3]
#    nseason<-nlevels(factor(faa$naa$Seas))
#    nageseason<-(nage+1)*nseason
#    nageseason3<-3*nageseason
    if(length(faa)==0){cat("in getFmort.ypr, length(faa)=",length(faa));browser()}
    fmort<-calcFAA.ypr(faa=faa,fmult=fmult,fmodifier=fmodifier,year=year,
      spawnseason=spawnseason,R0=R0,debug=debug,geomean=geomean)
  }else if(!is.null(fmort.list)  && is.list(fmort.list)){
   # browser()
    fmort<-modifyFAA.ypr(fmort.list=fmort.list,fmult=fmult,R0=R0,debug=debug)
#    nage<-fmort.list[["nage"]]
#    nfleet<-fmort.list[["nfleet"]]
#    nseason<-fmort.list[["nseason"]]
#    nageseason<-fmort.list[["nageseason"]]
#    nageseason3<-fmort.list[["nageseason3"]]
  }
##########################################################################################
## current or modifyed Fでのsprを計算
## 2011/03/21 fmoｒｔを作成した際のR0の値にかかわらず、SPRを正しく計算するようにした
  calc.spr<-function(fmort=NULL,debug=FALSE){
    if(is.null(fmort))stop("fmort is required in calc.spr")
    spr<-sum(fmort[["fmort.matrix"]][,"N"]*fmort[["fmort.matrix"]][,"Mat.Fec"])/fmort[["fmort.matrix"]][1,"N"]

    if(debug)browser()
    return(spr)
  }


##########################################################################################
## current or modifyed Fでのsprを計算
  spr<-calc.spr(fmort=fmort,debug=debug)
##########################################################################################
## spr_F=0を計算
  if(fmult!=0 && sum(fmodifier)!=0){
    fmort1<-modifyFmort.ypr(fmort=fmort,fmult=0,R0=R0,spawnseason=spawnseason,debug=debug)
    spr0<-calc.spr(fmort=fmort1,debug=debug)
#   spr0<-temp0$spr
  }else{
    spr0<-spr
  }
#########################################################################################
## %spr_current_or_modifiedFを計算
  perc_spr<-spr/spr0
####################################################
## catch weight by fleet and by ageを計算
 cw_fl<-calcCW.ypr(fmort)

 if(debug)write.csv(cw_fl,"cw_fl.csv")
# write.csv(fmort.df,"fmort.csv")
## ypr を計算
  ypr<-sum(cw_fl)

####################################################
## ypr by fleet を計算
  ypr.fl<-apply(cw_fl,2,sum)
  if(debug)cat(paste(ypr,"\n",sep=""),file="ypr.txt",append=TRUE)
  ypr.0.1.tmp<-NULL

#######################################################
## ypr,ypr by fleet, catch weight by fleet and by age
  calc.ypr<-function(fmort){
    cw_fl<-calcCW.ypr(fmort=fmort)
    ypr.fl<-apply(cw_fl,2,sum)
    ypr<-sum(ypr.fl)
    return(list(ypr=ypr,ypr.fl=ypr.fl,cw_fl=cw_fl))
  }
  rel_ypr<-NULL
#######################################################
 #   browser()
  ypr.tmp<-list(ypr=ypr,ypr.fl=ypr.fl,rel_ypr=rel_ypr,spr=spr,perc_spr=perc_spr,spr0=spr0,
    ypr.detail=cw_fl,fmult=fmult,fmort=fmort,Yield=ypr*R0,Y.fl=ypr.fl*R0,SSB=spr*R0,SSB0=spr0*R0)

  class(ypr.tmp)<-"ypr.0"
  return(ypr.tmp)
########################################################
  cateq<-function(f,m,n,w=1){
    cat<-f/(f+m)*(1-exp(-f-m))*n*w
    return(cat)
  }

##########################################################################################
## current or modified Fでのsprを計算
  calc.spr<-function(fmort,debug=FALSE){
    spr<-sum(fmort[["fmort.matrix"]][,"N"]*fmort[["fmort.matrix"]][,"Mat.Fec"])
    if(debug)browser()
    return(spr)
  }


# 漁獲方程式各種

  cateq_part<-function(f,fpart,m,n,w=1){
    Z<-f+m
    cvect<-fpart/Z
    cvect<-cvect*(1-exp(-Z))
    cvect<-cvect*n
    cvect<-w*cvect
    return(cvect)
  }

  cateq_partZ<-function(Z,fpart,n,w=1){
    cvect<-fpart/Z
    cvect<-cvect*(1-exp(-Z))
    cvect<-cvect*n
    cvect<-w*cvect
    return(cvect)
  }
  cateq_partZnoN<-function(Z,fpart,w=1){
    cvect<-fpart/Z
    cvect<-cvect*(1-exp(-Z))
    cvect<-w*cvect
    return(cvect)
  }

    cateq_partZnoNW<-function(Z,fpart){
    cvect<-fpart/Z
    cvect<-cvect*(1-exp(-Z))
    return(cvect)
  }
  cateq_partZexpZnoNW<-function(Z,expZ,fpart){
    cvect<-fpart/Z
    cvect<-cvect*expZ
    return(cvect)
  }
}

################################################################################################
##
## FMSYを計算する
##
##

calcFMSY<-function(year,report=NULL,R0=1,spawnseason,faa=NULL,fmodifier=ifelse(!is.null(faa),rep(1,dim(faa$faa.array)[3]),NULL),
  fmort.list=NULL,debug=FALSE,SR=NULL,calcB=FALSE,geomean=TRUE,intervals=c(0,5),tol=0.001,SRfn=NULL){
 # browser()
  if(is.null(faa) && is.null(fmort.list) && !is.null(report)){
    faa<-calFAA.ss3.x(report=report,is.plot=FALSE)
  }
  if(is.null(fmort.list) && !is.null(faa)){
    fmort.list<-calcFAA.ypr(faa=faa,fmult=fmult,fmodifier=fmodifier,year=year,
      spawnseason=spawnseason,R0=R0,debug=debug,geomean=geomean)
  }
  if(is.null(fmodifier))fmodifier<-rep(1,fmort.list$nfleet)

  if(is.null(SR)){
    if(is.null(report))stop("either object SR or report is required to calculate MSY" )
    SR<-read.spawner_recruit(report=report,plot=FALSE)
  }
  if(!is.null(SRfn))SR$SRfn<-SRfn
#  R0msy<-SR$R0
  SSB0<-SR$SSB0
  SRfn<-SR$SRfn
##############################################################################################
  tmp.fn<-function(x){
    spr<-calcSPR.ypr(faa=faa,year=year,fmult=x,R0=R0,spawnseason=spawnseason,fmort.list=fmort.list,fmodifier=fmodifier)$spr
    tmp.fn1<-if(debug){
      function(SSB){cat(paste("SSB=",SSB));tmp<-SSB/SRfn(SSB)-spr;cat(" ",tmp,"\n");return(tmp)}
    }else{
      function(SSB){SSB/SR$SRfn(SSB)-spr}
    }
    SSBeq<-uniroot(f=tmp.fn1,interval=c(0.00000001,SSB0),tol=min(tol,1.0e-6))$root
    Req<-SR$SRfn(SSBeq)
    ## return value : equiribrium yield given F
    return(getFmort.ypr.0(faa=faa,year=year,fmult=x,R0=Req,spawnseason=spawnseason,fmort.list=fmort.list,fmodifier=fmodifier)$ypr)
  }
##############################################################################################
  SY.maximizer<-optimize(f=tmp.fn,interval=interval,maximum=TRUE)
  ypr.MSY<-getFmort.ypr.0(faa=faa,year=year,fmult=SY.maximizer$maximum,R0=R0,spawnseason=spawnseason,fmort.list=fmort.list,
    fmodifier=fmodifier,debug=debug)

  if(calcB){
    ypr.MSY$SSB<-ypr.MSY$SSB_MSY<-tmp.fn(SY.maximizer$maximum)
    ypr.MSY$Yield<-ypr.MSY$MSY<-ypr.MSY$ypr*SRfn(ypr.MSY$SSB_MSY)
    ypr.MSY$R<-ypr.MSY$R_MSY<-SR$SRfn(ypr.MSY$SSB_MSY)
  }
  ypr.MSY$rel_ypr<-tmp.fn(x=1)/ypr.MSY$MSY
#################################################################################

  return(ypr.MSY)
}




################################################################################################
##
## F0.1を計算する
##
##

calcF0.1<-function(year,report=NULL,R0=1,spawnseason,faa=NULL,fmodifier=ifelse(!is.null(faa),rep(1,dim(faa$faa.array)[3]),NULL),
  fmort.list=NULL,stepsize=0.001,debug=FALSE,geomean=TRUE,calcB=FALSE,SR=NULL,SRfn=NULL){
 # browser()
  if(is.null(faa) && is.null(fmort.list)  && !is.null(report) ){
    faa<-calFAA.ss3.x(report=report,is.plot=FALSE)
  }
  if(is.null(fmort.list) && !is.null(faa)){
    fmort.list<-calcFAA.ypr(faa=faa,fmult=fmult,fmodifier=fmodifier,year=year,
      spawnseason=spawnseason,R0=R0,debug=debug,geomean=geomean)
  }
  if(is.null(fmodifier))fmodifier<-rep(1,fmort.list$nfleet)

  if(is.null(SR) && calcB){
    if(is.null(report))stop("either object SR or report is required with calcB in calcF0.1" )
    SR<-read.spawner_recruit(report=report,plot=FALSE)
  }
  if(!is.null(SRfn))SR$SRfn<-SRfn
#  R0msy<-SR$R0
  SSB0<-SR$SSB0
  SRfn<-SR$SRfn


  ypr0<-getFmort.ypr.0(fmult=0,fmodifier=fmodifier,year=year,faa=faa,fmort.list=fmort.list,R0=R0,spawnseason=spawnseason)
  if(debug){cat("ypr0=");print(ypr0$ypr)}
  ypr1<-getFmort.ypr(fmult=stepsize,fmodifier=fmodifier,year=year,faa=faa,fmort.list=fmort.list,R0=R0,spawnseason=spawnseason,maximize=TRUE)
  if(debug){cat("ypr1=");print(ypr1$ypr)}
# browser()
  slopeOrigin<-(ypr1$ypr-ypr0$ypr)/stepsize
  slope01<-slopeOrigin*0.1
  if(debug)cnt<-0
  slope<-function(x){
    fmultx<-x
 #    browser()
    ypr0<-getFmort.ypr.0(faa=faa,fmort.list=fmort.list,fmult=fmultx,fmodifier=fmodifier,year=year,R0=R0,spawnseason=spawnseason)
    fmultx<-(x+stepsize)
    ypr1<-getFmort.ypr.0(faa=faa,fmort.list=fmort.list,fmult=fmultx,fmodifier=fmodifier,year=year,R0=R0,spawnseason=spawnseason)
    slope<-(ypr1$ypr-ypr0$ypr)/stepsize
    if(debug)cnt<-cnt+1
    if(debug)cat("slope=",slope," counter=",cnt,"\n")
    return(slope-slope01)
  }
  if(debug)browser()
  #browser()
  temp<-uniroot(f=slope,interval=c(0,ypr1$ypr.opt$fmult))
  ypr<-getFmort.ypr.0(fmult=temp$root,fmodifier=fmodifier,year=year,faa=faa,fmort.list=fmort.list,R0=R0,spawnseason=spawnseason)
  if(calcB){
    ypr$SSB<-ypr$spr*R0
    ypr$Yield<-ypr$ypr*R0
  }
  return(ypr)
}

###################################################################################
##
##  Fmed を計算する
##

calcFmed<-function(year,report=NULL,spawnseason,fmodifier=NULL,SR=NULL,range=c(0,5),
  tol=0.01,debug=FALSE,faa=NULL,fmort.list=NULL,geomean=TRUE,calcB=FALSE){

  if(is.null(faa) && is.null(fmort.list)){
    faa<-calFAA.ss3.x(report=report,is.plot=FALSE)
  }
  if(is.null(fmort.list) && !is.null(faa)){
    fmort.list<-calcFAA.ypr(faa=faa,fmult=fmult,fmodifier=fmodifier,year=year,
      spawnseason=spawnseason,R0=R0,debug=debug,geomean=geomean)
  }

  if(is.null(fmodifier))fmodifier<-rep(1,fmort.list$nfleet)
  if(is.null(SR)){
    if(!is.null(report)){
      SR<-read.spawner_recruit(report=report,plot=FALSE)
    }else{
      stop("either SR or report is necessary for calcFmed")
    }
  }

  RPSmed<-median(SR$sr[SR$sr[,9]=="Main","RPS"])
  SPRmed<-1/RPSmed
  FmultFmed<-SPR2fmult(spr=SPRmed,faa=faa,year=year,R0=1,spawnseason=spawnseason,fmort.list=fmort.list,
    fmodifier=fmodifier,range=range,tol=tol,debug=debug,geomean=geomean)
  ypr<-getFmort.ypr.0(fmult=FmultFmed,fmodifier=fmodifier,year=year,faa=faa,fmort.list=fmort.list,R0=R0,spawnseason=spawnseason)
#  return(FmultFmed)
  if(calcB){
    ypr$SSB<-SPRmed*R0
    ypr$Yield<-ypr$ypr*R0
  }
  return(ypr)
}

calcFloss<-function(year,report=NULL,spawnseason=NA,fmodifier=NULL,SR=NULL,range=c(0,5),tol=0.01,debug=FALSE,
              faa=NULL,nboot=1,fmort.list=fmort.list,geomean=TRUE){
  if(is.null(faa) && is.null(fmort.list)   && !is.null(report)){
    faa<-calFAA.ss3.x(report=report,is.plot=FALSE)
  }
  if(is.null(fmort.list) && !is.null(faa)){
    fmort.list<-calcFAA.ypr(faa=faa,fmult=fmult,fmodifier=fmodifier,year=year,
      spawnseason=spawnseason,R0=R0,debug=debug,geomean=geomean)
  }
  if(is.null(fmodifier))fmodifier<-rep(1,fmort.list$nfleet)

  if(is.null(SR)){
    if(!is.null(report)){
      SR<-read.spawner_recruit(report=report,plot=FALSE)
    }else{
      stop("either SR or report is necessary for calcFloss")
    }
  }

  calcFloss.0<-function(SR,faa,year,spawnseason,range,tol,debug,geomean){
    lowestSSB<-min(SR$sr[SR$sr[,9]=="Main","spawn_bio"])
    lowestYear<-unique(as.numeric(SR$sr[SR$sr[,2]==lowestSSB,"year"]))
    lowestRPS<-unique(SR$sr[SR$sr[,2]==lowestSSB,"RPS"])
    lowestSPR<-1/lowestRPS
    FmultFloss<-SPR2fmult(spr=lowestSPR,faa=faa,year=year,R0=1,spawnseason=spawnseason,fmort.list=fmort.list,
      fmodifier=fmodifier,range=range,tol=tol,debug=debug,geomean=geomean) #lowestSPRの時のFを計算
    return(FmultFloss)
  }

  FmultFloss<-calcFloss.0(SR=SR,faa=faa,year=year,spawnseason=spawnseason,
        range=range,tol=tol,debug=debug,geomean=geomean)
  if(nboot>1){
    FUNC.finally<-function(SR){
      lowestSSB<-min(SR$sr[SR$sr[,9]=="Main","spawn_bio"])
      lowestYear<-unique(as.numeric(SR$sr[SR$sr[,2]==lowestSSB,"year"]))
      lowestRPS<-unique(SR$sr[SR$sr[,2]==lowestSSB,"RPS"])
      lowestSPR<-1/lowestRPS
      return(list(lowestSSB,lowestYear,lowestRPS,lowestSPR))
    }
    FmultFloss.vect<-sapply(1:nboot,FUN=function(i){
        sr.tmp<-SR$sr[SR$sr[,9]=="Main",]
        sr.new<-sr.tmp[sample(1:nrow(sr.tmp),replace=TRUE),]
        SR.new<-list(sr=sr.new)

        return.val<-try(
          calcFloss.0(SR=SR.new,faa=faa,year=year,spawnseason=spawnseason,
              range=range,tol=tol,debug=debug,geomean=geomean),
          TRUE)
        cat(i,return.val,"\n")
        return(return.val)
      }
    )
  }
  ypr<-getFmort.ypr.0(fmult=FmultFloss,fmodifier=fmodifier,year=year,faa=faa,fmort.list=fmort.list,R0=R0,spawnseason=spawnseason)
  if(calcB){
    ypr$SSB<-ypr$spr*R0
    ypr$Yield<-ypr$ypr*R0
  }
  if(nboot>1){
#    return(list(FmultFloss=FmultFloss,FmultFloss.vect=FmultFloss.vect))
    return(list(ypr=ypr,FmultFloss.vect=FmultFloss.vect))
  }else{
#  return(FmultFmed)
    return(ypr)
#    return(FmultFloss)
  }
}

calcBRP<-calcBRP.20110315_2<-function(runname,repfile="report.sso",year,spawnseason=4,fmodifier,Fmax=TRUE,FMSY=TRUE,
  FSPR=c(10,20,30,40),F0.1=TRUE,Fmed=TRUE,Floss=TRUE,tol=0.01,range=c(0,5),debug=FALSE,faa=NULL,multiFAA=FALSE,SR=NULL,
  SRfn=NULL,geomean=TRUE,inverse=FALSE,calcB=TRUE){
  if(missing(year))stop("year is missing")
  if(missing(runname))runname<-""
  if(!is.null(faa) && !multiFAA){
#    cat("HERE\n")
    if(missing(fmodifier))fmodifier<-rep(1,dim(faa$faa.array)[3])
    if(is.null(SR) && !file.exist(repfile)){
      report<-getReport.sso(repfile=repfile)
      SR<-read.spawner_recruit(report=report,plot=FALSE)
    }else{
      stop(paste(repfile," does not exist"))
    }
    if(!is.null(SRfn))SR$SRfn<-SRfn
    R0<-ifelse(calcB,SR$R0,1)
    yprs<-calcBRP.0(runname=faa$repfile,faa=faa,year=year,spawnseason=spawnseason,fmodifier=fmodifier,
      Fmax=Fmax,FMSY=FMSY,F0.1=F0.1,FSPR=FSPR,Fmed=Fmed,Floss=Floss,tol=tol,range=range,debug=debug,SR=SR,
      geomean=geomean,inverse=inverse,calcB=calcB,R0=R0)
    BRPmatF<-yprs$BRPvectF
    if(calcB){BRPmatB<-yprs$BRPvectB}else{BRPmatB<-NULL}
    cat("done\n")
  }else{
    if(is.null(faa) | is.null(SR)) reports<-getReport.sso(repfile=repfile,oldStyle=FALSE)
    if(is.null(faa)){
 #     browser()
      faas<-lapply(reports[[1]],FUN=function(report){calFAA.ss3.x(report=report,is.plot=FALSE)})
    }else{
      faas<-faa
    }
    if(is.null(SR)){
      SRs<-lapply(reports[[1]],FUN=function(report){read.spawner_recruit(report=report,plot=FALSE)})
    }
    if(!is.null(SRfn)){
      if(length(SRfn)==length(SRs)){
        for(i in 1:length(SRfn))SRs[[i]]$SRfn<-SRfn[i]
      }
    }
    if(missing(fmodifier))fmodifier<-lapply(faas,FUN=function(faa){rep(1,dim(faa$faa.array)[3])})
    BRPmatF<-NULL
    BRPmatB<-NULL
    yprs<-list()
    for(i in 1:length(faas)){
      if(debug)browser()
      R0<-ifelse(calcB,SRs[[i]]$R0,1)
      yprs[[i]]<-calcBRP.0(runname=faas[[i]]$repfile,faa=faas[[i]],year=year,spawnseason=spawnseason,fmodifier=fmodifier[[i]],
        Fmax=Fmax,FMSY=FMSY,F0.1=F0.1,FSPR=FSPR,Fmed=Fmed,Floss=Floss,tol=tol,range=range,debug=debug,SR=SRs[[i]],geomean=geomean,
        inverse=inverse,R0=R0)
      BRPmatF<-rbind(BRPmatF,yprs[[i]]$BRPvectF)
      BRPmatB<-rbind(BRPmatF,yprs[[i]]$BRPvectB)
      if(length(faas)>1)rownames(BRPmatF)[i]<-rownames(BRPmatB)[i]<-repfile[i]
      cat(paste("done", repfile[i],"\n"))
    }
  }
  BRP<-list(runname=runname,repfile=repfile,year=year,spawnseason=spawnseason,BRPmatF=BRPmatF,BRPmatB=BRPmatB,ypr=yprs)
  class(BRP)<-"BRPnew"
#  browser()
  return(BRP)
}

print.BRPnew<-function(BRP,digits= max(3, getOption("digits") - 3)){
  print.default(formatC(BRP$BRPmatF,digits=digits),quote=FALSE)
}


calcBRP.20110315<-function(runname,repfile="report.sso",year,spawnseason=4,fmodifier,Fmax=TRUE,FMSY=TRUE,
  FSPR=c(10,20,30,40),F0.1=TRUE,Fmed=TRUE,Floss=TRUE,tol=0.01,range=c(0,5),debug=FALSE,faa=NULL,multiFAA=FALSE){
  if(missing(year))stop("year is missing")
  if(missing(runname))runname<-""
  if(is.null(faa)){
    faa<-calFAA.ss3.x(report=ifelse(length(report)==1,report,report[1]),is.plot=FALSE)
    if(missing(fmodifier))fmodifier<-rep(1,dim(faa$faa.array)[3])
    BRPmat<-calcBRP.0(runname=ifelse(length(repfile)==1,repfile,repfile[1]),faa=faa,year=year,spawnseason=spawnseason,fmodifier=fmodifier,
      Fmax=Fmax,FMSY=FMSY,F0.1=F0.1,FSPR=FSPR,Fmed=Fmed,Floss=Floss,tol=tol,range=range,debug=debug)
    cat(paste("done", ifelse(length(repfile)==1,repfile,repfile[1]),"\n"))
    if(length(repfile)>1){
      for(i in 2:length(repfile)){
        faa<-calFAA.ss3.x(report=report[i],is.plot=FALSE)
        if(missing(fmodifier))fmodifier<-rep(1,dim(faa$faa.array)[3])
        BRPmat<-rbind(BRPmat,calcBRP.0(runname=repfile[i],faa=faa,year=year,spawnseason=spawnseason,fmodifier=fmodifier,
          Fmax=Fmax,FMSY=FMSY,F0.1=F0.1,FSPR=FSPR,Fmed=Fmed,Floss=Floss,tol=tol,range=range,debug=debug))
        rownames(BRPmat)[i]<-repfile[i]
        cat(paste("done", repfile[i],"\n"))
      }
      rownames(BRPmat)[1]<-repfile[1]
    }
  }else{
    if(!multiFAA){
      if(missing(fmodifier))fmodifier<-rep(1,dim(faa$faa.array)[3])
      BRPmat<-calcBRP.0(runname=ifelse(length(repfile)==1,repfile,repfile[1]),faa=faa,year=year,spawnseason=spawnseason,fmodifier=fmodifier,
        Fmax=Fmax,FMSY=FMSY,F0.1=F0.1,FSPR=FSPR,Fmed=Fmed,Floss=Floss,tol=tol,range=range,debug=debug)
      cat("done for FAA\n")
    }else{
      BRPmat<-NULL
      for(i in 1:length(faa)){
        if(missing(fmodifier))fmodifier<-rep(1,dim(faa[[i]]$faa.array)[3])
        BRPmat<-rbind(BRPmat,calcBRP.0(runname=repfile[i],report=report,year=year,spawnseason=spawnseason,fmodifier=fmodifier,
          Fmax=Fmax,FMSY=FMSY,F0.1=F0.1,FSPR=FSPR,Fmed=Fmed,Floss=Floss,tol=tol,range=range,debug=debug,faa=faa[[i]]))
          rownames(BRPmat)[i]<-repfile[i]
          cat(paste("done", i,"th faa\n"))
      }
    }
  }
  class(BRPmat)<-"BRP"
  return(BRPmat)
}


calcBRP.old.20110316<-function(runname,repfile="report.sso",year,spawnseason=4,fmodifier,Fmax=TRUE,FMSY=TRUE,FSPR=c(10,20,30,40),F0.1=TRUE,Fmed=TRUE,Floss=TRUE,tol=0.01,range=c(0,5),debug=FALSE,faa=NULL){
  if(missing(year))stop("year is missing")
  if(missing(runname))runname<-""

  if(is.null(faa) && length(repfile)==1){
     report<-getReport.sso(repfile=repfile)
    faa<-calFAA.ss3.x(report=report,is.plot=FALSE)
    if(missing(fmodifier))fmodifier<-rep(1,dim(faa$faa.array)[3])
    return(calcBRP.0(runname=runname,report=report,year=year,spawnseason=spawnseason,fmodifier=fmodifier,
      Fmax=Fmax,FMSY=FMSY,F0.1=F0.1,FSPR=FSPR,Fmed=Fmed,Floss=Floss,tol=tol,range=range,debug=debug))
  }else if(is.null(faa) && length(repfile)>1){
    for(filename in repfile){
      if(!file.exists(filename)){stop(paste(filename, "does not exist"))}
    }
    report<-getReport.sso(repfile=repfile[1])
    faa<-calFAA.ss3.x(report=report,is.plot=FALSE)
    if(missing(fmodifier))fmodifier<-rep(1,dim(faa$faa.array)[3])
    BRPmat<-calcBRP.0(runname=repfile[1],report=report,year=year,spawnseason=spawnseason,fmodifier=fmodifier,
      Fmax=Fmax,FMSY=FMSY,F0.1=F0.1,FSPR=FSPR,Fmed=Fmed,Floss=Floss,tol=tol,range=range,debug=debug)
    cat(paste("done", repfile[1]))
    for(i in 2:length(repfile)){
      report<-getReport.sso(repfile=repfile[i])
      faa<-calFAA.ss3.x(report=report,is.plot=FALSE)
      if(missing(fmodifier))fmodifier<-rep(1,dim(faa$faa.array)[3])
      BRPmat<-rbind(BRPmat,calcBRP.0(runname=repfile[i],report=report,year=year,spawnseason=spawnseason,fmodifier=fmodifier,
        Fmax=Fmax,FMSY=FMSY,F0.1=F0.1,FSPR=FSPR,Fmed=Fmed,Floss=Floss,tol=tol,range=range,debug=debug))
        rownames(BRPmat)[i]<-repfile[i]
        cat(paste("done", repfile[i],"\n"))
    }
    rownames(BRPmat)[1]<-repfile[1]
    class(BRPmat)<-"BRP"
    return(BRPmat)
  }else{
    if(length(faa)==1){
#    faa<-calFAA.ss3.x(report=report,is.plot=FALSE)
    if(missing(fmodifier))fmodifier<-rep(1,dim(faa$faa.array)[3])
    return(calcBRP.0(runname=runname,year=year,spawnseason=spawnseason,fmodifier=fmodifier,
      Fmax=Fmax,FMSY=FMSY,F0.1=F0.1,FSPR=FSPR,Fmed=Fmed,Floss=Floss,tol=tol,range=range,debug=debug,faa=faa))
    }else{
    report<-getReport.sso(repfile=repfile[1])
#    faa<-calFAA.ss3.x(report=report,is.plot=FALSE)
    if(missing(fmodifier))fmodifier<-rep(1,dim(faa[[1]]$faa.array)[3])
    BRPmat<-calcBRP.0(runname=repfile[1],year=year,spawnseason=spawnseason,fmodifier=fmodifier,
      Fmax=Fmax,FMSY=FMSY,F0.1=F0.1,FSPR=FSPR,Fmed=Fmed,Floss=Floss,tol=tol,range=range,debug=debug,faa=faa[[1]])
    cat(paste("done 1st faa\n"))
    }
    for(i in 2:length(faa)){
#      report<-getReport.sso(repfile=repfile[i])
#      faa<-calFAA.ss3.x(report=report,is.plot=FALSE)
      if(missing(fmodifier))fmodifier<-rep(1,dim(faa[[i]]$faa.array)[3])
      BRPmat<-rbind(BRPmat,calcBRP.0(runname=repfile[i],report=report,year=year,spawnseason=spawnseason,fmodifier=fmodifier,
        Fmax=Fmax,FMSY=FMSY,F0.1=F0.1,FSPR=FSPR,Fmed=Fmed,Floss=Floss,tol=tol,range=range,debug=debug,faa=faa[[i]]))
        rownames(BRPmat)[i]<-repfile[i]
        cat(paste("done", i,"th faa\n"))
    }
  }
}



#### 2010/02/23 Floss の計算も組み込んだ
#### 2010/10/09 Inplemented calculation of FMSY given S-R relationship
#### 2011/03/21 chenged return value to list of F-BRPs, B-BRPs and associated results of calculations
calcBRP.0<-function(runname,report=NULL,year,spawnseason=4,fmodifier,Fmax=TRUE,FSPR=c(10,20,30,40),F0.1=TRUE,
  Fmed=TRUE,Floss=TRUE,FMSY=TRUE, tol=0.01,range=c(0,5),debug=FALSE,debug2=FALSE,faa=NULL,fmult=1,
  geomean=TRUE,R0=1,SR=NULL,inverse=FALSE,calcB=FALSE){
  if(is.null(faa)){
    if(!is.null(report)){
      faa<-calFAA.ss3.x(report=report,is.plot=FALSE)
    }else{
      stop("Either faa or report is needed in calcBRP.0")
    }
  }
  if(is.null(fmodifier))fmodifier<-rep(1,dim(faa$faa.array)[3])
  if(missing(runname))runname<-""
  cnt<-0
  if(Fmax)cnt<-cnt+1
  if(FMSY)cnt<-cnt+1
  if(F0.1)cnt<-cnt+1
  if(Fmed)cnt<-cnt+1
  if(Floss)cnt<-cnt+1
  if(!is.logical(FSPR))cnt<-cnt+length(FSPR)
  fmort.list<-calcFAA.ypr(faa=faa,fmult=fmult,fmodifier=fmodifier,year=year,spawnseason=spawnseason,R0=R0,debug=debug,geomean=geomean)
  if((FMSY||Fmed) && is.null(SR)){SR<-read.spawner_recruit(report=report,plot=FALSE)}
 # Fmax and F0.1
  if(Fmax || F0.1 || FMSY){
    ypr1<-getFmort.ypr(fmult=1,fmort.list=fmort.list,year=year,spawnseason=spawnseason,
      fmodifier=fmodifier,maximize=Fmax,F0.1=F0.1,FMSY=FMSY,debug=debug,interval=range,SR=SR,R0=R0,calcB=calcB)
    cat("Done getFmort.ypr\n")
  }
  if(Fmed){
    yprFmed<-calcFmed(year=year,report=report,spawnseason=spawnseason,
      fmort.list=fmort.list,fmodifier=fmodifier,tol=tol,debug=debug,
        faa=faa,geomean=geomean,SR=SR,R0=R0)
    cat("Done calcFmed\n")
  }
  if(Floss){
    yprFloss<-calcFloss(year=year,report=report,spawnseason=spawnseason,fmodifier=fmodifier,
      range=range,tol=tol,debug=debug,faa=faa,geomean=geomean,R0=R0)
    cat("Done calcFloss\n")
  }

 #  browser()
  Fmax.value<-ifelse(Fmax,ypr1$ypr.opt$fmult,NA)
  FMSY.value<-ifelse(FMSY,ypr1$ypr.MSY$fmult,NA)
  F0.1.value<-ifelse(F0.1,ypr1$ypr.0.1$fmult,NA)
  Fmed.value<-ifelse(Fmed,yprFmed$fmult,NA)

  if(!is.logical(FSPR)){
    F_Perc_SPR<-numeric(length(FSPR))
    yprSPR<-list()
    for (i in 1:length(FSPR)){
      F_Perc_SPR[i]<-SPR2fmult(perc_spr=FSPR[i]/100.0,faa=faa,year=year,R0=R0,spawnseason=spawnseason,
        fmodifier=fmodifier,range=range,tol=tol,debug=debug,geomean=geomean,percent=TRUE)
      yprSPR[[i]]<-getFmort.ypr.0(fmult=F_Perc_SPR[i],fmodifier=fmodifier,year=year,faa=faa,
        fmort.list=fmort.list,R0=R0,spawnseason=spawnseason)
      cat("Done PERC_SPR2fmult ",FSPR[i],"\n")
    }
    names(F_Perc_SPR)<-paste("F",FSPR,"%",sep="")
    cat("Done F_SPR\n")
  }else{
    F_Perc_SPR<-NA
  }
  Floss.value<-ifelse(Floss,yprFloss$fmult,NA)

  BRPvect<-numeric(cnt)
  yprList<-list()
  i<-1
  if(Fmax){
    names(BRPvect)[i]<-"Fmax"
    BRPvect[i]<-Fmax.value
    yprList[[i]]<-ypr1$ypr.opt
    i<-i+1
  }
  if(FMSY){
    names(BRPvect)[i]<-"FMSY"
    BRPvect[i]<-FMSY.value
    yprList[[i]]<-ypr1$ypr.MSY
    i<-i+1
  }

  if(F0.1){
    names(BRPvect)[i]<-"F0.1"
    BRPvect[i]<-F0.1.value
    yprList[[i]]<-ypr1$ypr.0.1
    i<-i+1
  }
  if(Fmed){
    names(BRPvect)[i]<-"Fmed"
    BRPvect[i]<-Fmed.value
    yprList[[i]]<-yprFmed
    i<-i+1
  }
  if(Floss){
    names(BRPvect)[i]<-"Floss"
    BRPvect[i]<-Floss.value
    yprList[[i]]<-yprFloss
    i<-i+1
  }
  if(!is.logical(FSPR)){
    names(BRPvect)[i+(1:length(FSPR))-1]<-names(F_Perc_SPR)
    BRPvect[i+(1:length(FSPR))-1]<-F_Perc_SPR[1:length(FSPR)]
    yprList[i+(1:length(FSPR))-1]<-yprSPR[1:length(FSPR)]
  }
  if(inverse)BRPvect<-1/BRPvect
  return(list(BRPvectF=BRPvect,BRPvectB=BRPvectB,yprList=yprList))
#   return(list(runname=runname,Fmax=Fmax.value,F0.1=F0.1.value,Fmed=Fmed.value,FSPR=F_Perc_SPR))
}


if(0){

years<-1952:2002

eltime<-system.time(ypr.vect<-lapply(years,function(year){ getFmort.ypr(fmult=1,faa=faa,year=year:(year+2),maximize=TRUE,F0.1=TRUE,spawnseason=4)}))
print(eltime)

years<-1952:2005

eltime<-system.time(ypr.vect2<-lapply(years,function(year){ getFmort.ypr(fmult=1,faa=faa,year=year,maximize=TRUE,F0.1=TRUE,spawnseason=4)}))
print(eltime)


aaa<-list(fmult=unlist(lapply(ypr.vect,"[[","fmult")),ypr=unlist(lapply(ypr.vect,"[[","ypr")),
  spr=unlist(lapply(ypr.vect,"[[","perc_spr")),fmult.opt=unlist(lapply(ypr.vect,"[[","fmult.opt")),
  ypr.opt=unlist(lapply(ypr.vect,"[[","ypr.opt")),rel_ypr=unlist(lapply(ypr.vect,"[[","rel_ypr")),
  perc_spr=unlist(lapply(ypr.vect,"[[","perc_spr")),
  spr.opt=unlist(lapply(ypr.vect,"[[","spr.opt")),perc_spr.opt=unlist(lapply(ypr.vect,"[[","perc_spr.opt")))

aaa2<-list(fmult=unlist(lapply(ypr.vect2,"[[","fmult")),ypr=unlist(lapply(ypr.vect2,"[[","ypr")),
  spr=unlist(lapply(ypr.vect2,"[[","perc_spr")),fmult.opt=unlist(lapply(ypr.vect2,"[[","fmult.opt")),
  ypr.opt=unlist(lapply(ypr.vect2,"[[","ypr.opt")),rel_ypr=unlist(lapply(ypr.vect2,"[[","rel_ypr")),
  perc_spr=unlist(lapply(ypr.vect2,"[[","perc_spr")),
  spr.opt=unlist(lapply(ypr.vect2,"[[","spr.opt")),perc_spr.opt=unlist(lapply(ypr.vect2,"[[","perc_spr.opt")))



}
testAll<-function(faa,range=c(0,5)){
multiplier<-seq(range[1],range[2],by=0.01)
ypr0<-getFmort.ypr(year=2002:2004,spawnseason=4,faa=faa,fmult=0)
cat("ypr0=\n");print(ypr0$ypr)
ypr1<-getFmort.ypr(fmult=1,faa=faa,year=2002:2004,spawnseason=4)
cat("ypr1=\n");print(ypr1)
ypr2<-getFmort.ypr(fmult=1,faa=faa,year=2002:2004,spawnseason=4,maximize=TRUE,F0.1=FALSE,interval=range)
cat("ypr2=\n");print(ypr2)
ypr3<-getFmort.ypr(fmult=1,faa=faa,year=2002:2004,spawnseason=4,maximize=TRUE,interval=range)
cat("ypr3=\n");print(ypr3)
F01<-calcF0.1(faa=faa,spawnseason=4,year=2002:2004)
eltime<-
  system.time(ypr.vect<-lapply(multiplier,
  function(fmult){cat("fmult=",fmult,"\n");getFmort.ypr(fmult=fmult,faa=faa,year=2004:2006,maximize=TRUE,F0.1=FALSE)}))
print(eltime)
#
aaa<-list(fmult=unlist(lapply(ypr.vect,"[[","fmult")),ypr=unlist(lapply(ypr.vect,"[[","ypr")),
  spr=unlist(lapply(ypr.vect,"[[","perc_spr")),fmult.opt=unlist(lapply(lapply(ypr.vect,"[[","ypr.opt"),"[[","fmult")),
  ypr.opt=unlist(lapply(lapply(ypr.vect,"[[","ypr.opt"),"[[","ypr")),rel_ypr=unlist(lapply(ypr.vect,"[[","rel_ypr")),
  spr.opt=unlist(lapply(lapply(ypr.vect,"[[","ypr.opt"),"[[","spr")),perc_spr.opt=unlist(lapply(lapply(ypr.vect,"[[","ypr.opt"),"[[","perc_spr")))

browser()

#optimize(f=function(x){fmult<-x*fmult;temp<-getFmort.ypr(fmult=fmult,year=year,faa,R0=R0,spawnseason=spawnseason);return(temp$ypr)},interval=c(0,5))

#optimize(f=function(x){fmultx<-x*fmult;temp<-getFmort.ypr(faa=faa,fmult=fmultx,year=2002:2004,R0=1,spawnseason=4);return(temp$ypr)},interval=c(0,5),maximum=TRUE)
#getFmort.ypr(year=2002:2004,spawnseason=4,faa=faa,fmult=1)
#

#i<-1
#s<-1
#       cateq_part(fmort.df$Total[seq(from=(nage+1)*nseason+s,to=(nage+1)*nseason*3,by=nseason)],
#         fmort.df[seq(from=(nage+1)*nseason+s,to=(nage+1)*nseason*3,by=nseason),i+1],nma.sorted$M[(nage*nseason+s)]/4.0,
#         fmort.df$N[seq(from=(nage+1)*nseason+s,to=(nage+1)*nseason*3,by=nseason)],nma.sorted[(nage*nseason+s),20+(i-1)*2])


plot(aaa$fmult,aaa$rel_ypr*100,type="l",xlab="F-multiplier",ylab="%SPR and YPR as YPR at Fmax as 100%")
points(aaa$fmult,aaa$spr*100,type="l")
return(invisible(aaa))
}



